A Pen created at CodePen.io. You can find this one at https://codepen.io/fluxus/pen/gPWvZm.

 Another take on my flexbox fullscreen overlay navigation. Spicing things up with a bit of Velocity.js